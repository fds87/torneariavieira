# Tornearia Vieira — Redesign completo (2026)

Atualização visual de **toda a vitrine** do site: home + páginas internas
(catálogo, produto, carrinho, login/conta). Visual industrial/técnico, **logo
oficial**, **tema escuro por padrão** (toggle claro), micro-interações e
**responsivo/mobile** refinado.

Mantém 100% da sua arquitetura Nuxt: `content.js`, stores (cart/auth/products/
freight), `useTheme`, layouts, middleware e rotas. Nada de API muda.

---

## 1. Como aplicar (copiar e substituir)

Copie o conteúdo de `apps/web/` desta pasta para o seu repo, **mantendo os
mesmos caminhos**.

### Arquivos novos
| Arquivo | Caminho no repo |
|---|---|
| Logo (tema claro) | `apps/web/public/logo.png` |
| Logo (tema escuro) | `apps/web/public/logo-dark.png` |
| Plugin de interações | `apps/web/app/plugins/ui.client.ts` |
| Overlay de cotas | `apps/web/app/components/ui/DimOverlay.vue` |

### Arquivos substituídos
| Arquivo | Caminho no repo |
|---|---|
| Estilos globais | `apps/web/app/assets/css/main.css` |
| **Bridge de tokens** | `apps/web/src/assets/tokens.css` |
| App root | `apps/web/app/app.vue` |
| Layout padrão | `apps/web/app/layouts/default.vue` |
| Composable de tema | `apps/web/app/composables/useTheme.js` |
| Header | `apps/web/app/components/layout/AppHeader.vue` |
| Footer | `apps/web/app/components/layout/AppFooter.vue` |
| Seção Hero | `apps/web/app/components/sections/HeroSection.vue` |
| Seção Serviços | `apps/web/app/components/sections/ServicesSection.vue` |
| Seção Sobre | `apps/web/app/components/sections/AboutSection.vue` |
| Seção Diferenciais | `apps/web/app/components/sections/WhyUsSection.vue` |
| Seção Contato | `apps/web/app/components/sections/ContactSection.vue` |
| **ProductCard** | `apps/web/src/components/products/ProductCard.vue` |
| Tipos de produto | `apps/web/src/types/product.ts` |
| Home | `apps/web/app/pages/index.vue` |
| Catálogo | `apps/web/app/pages/catalogo.vue` |
| Página de produto | `apps/web/app/pages/produto/[slug].vue` |
| Carrinho | `apps/web/app/pages/carrinho.vue` |
| Login | `apps/web/app/pages/conta/entrar.vue` |

Depois:

```bash
cd apps/web
npm install   # nada novo, só garantir
npm run dev
```

> 💡 As demais páginas internas (checkout, conta/*, admin, pagamento, pedido)
> **adotam o novo visual automaticamente** — elas usam os tokens
> (`--bg-card`, `--accent`, `--c-stone-*`, `--radius-*`) que agora apontam para
> a nova paleta escura/dourada via `src/assets/tokens.css`. Não precisa editar
> uma por uma. Se quiser depois dar o "tratamento premium" (cantos chanfrados,
> labels mono) em alguma específica, use `carrinho.vue`/`entrar.vue` como modelo.

---

## 2. ⚠️ Atenção: ordem de carregamento do CSS

`main.css` (fonte da verdade dos tokens `--c-*`) precisa ser carregado **antes**
de `src/assets/tokens.css` (o bridge). Confira no seu `nuxt.config.ts` a chave
`css: [...]` — a ordem deve ser:

```ts
css: [
  '@/assets/css/main.css',     // 1º — define :root e :root.dark
  '~/../src/assets/tokens.css' // 2º — bridge de aliases (ajuste o caminho ao seu setup)
]
```

(No seu projeto o `tokens.css` já era importado depois — então provavelmente
não precisa mexer. Só confirme.)

---

## 3. O que mudou — resumo

- **Tema escuro é o padrão** (`useTheme.js`). Continua via classe `.dark` no
  `<html>`, então middleware/admin/checkout seguem funcionando.
- **Tokens** unificados: `:root` = claro, `:root.dark` = escuro. O `tokens.css`
  agora mapeia todo o vocabulário legado para os tokens novos — incluindo trocar
  a fonte do corpo para **Space Grotesk** e zerar os `--radius-*` (visual
  industrial de cantos retos) e deixar `.btn--primary` chanfrado.
- **Logo oficial** no header e footer, com troca automática claro/escuro.
- **ProductCard** repensado para tornearia: categoria (Injetora/Bucha/Eixo/
  Conjunto…), selo "Sob encomenda", preço **"Sob consulta"** quando não há
  estoque, overlay de cotas técnicas. Sem nada de churrasco.
- **Catálogo**: filtros por categoria + bloco CTA "fabricamos sob desenho".
- **Página de produto**: ficha técnica (material, tolerância, fabricação,
  disponibilidade), preço ou "Sob consulta" → orçamento via WhatsApp, selos de
  confiança. Toda a copy reescrita para usinagem.
- **Carrinho** e **Login** restilizados no padrão industrial.
- **Interações** num único plugin client (`ui.client.ts`): diretivas
  `v-reveal` / `v-count` + barra de progresso, mira do cursor, botões
  magnéticos e WhatsApp flutuante.

> As categorias usadas (`injetora`, `bucha`, `eixo`, `conjunto`, `mola`,
> `cabecote`, `peca`, `servico`, `outros`) estão em `src/types/product.ts`.
> Ajuste seu seed/admin de produtos para usar esses valores. Categorias antigas
> de churrasco continuam aceitas no tipo (compatibilidade), mas sem rótulo
> dedicado no card.

---

## 4. Dados de contato

Tudo puxa de `app/data/content.js` (`site.phoneFormatted`, `site.email`,
`site.whatsapp`, etc.). O número usado é **(41) 99980-2662**. Ajuste lá se for
outro — propaga para header, footer, contato, produto e WhatsApp flutuante.

---

## 5. Previews estáticos (sem build)

Na pasta `torneariavieira-home/` (fora deste pacote):
- `index.html` — home desktop
- `mobile.html` — home em 2 aparelhos (claro/escuro)
- `internas.html` — catálogo, produto, carrinho e login
